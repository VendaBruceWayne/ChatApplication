﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SuperSimpleTcp;


namespace MessageAppClient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SimpleTcpClient client;
        string ip;


        private void txtIP_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {


            client.Connect();

        }

        private void Events_DataReceived(object sender, DataReceivedEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {

                byte[] receivedData = e.Data.ToArray();
                rtbChats.Text += $"{Environment.NewLine} {e.IpPort}: {Encoding.UTF8.GetString(receivedData)}";
            }); 
        }

        private void Events_Disconnected(object sender, ConnectionEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                rtbChats.Text += $"{Environment.NewLine} {e.IpPort} Disconnected...{e.Reason}";
               // ListBox1.Items.Remove(e.IpPort);

            });
        }

        private void Events_Connected(object sender, ConnectionEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                rtbChats.Text += $"{Environment.NewLine} {e.IpPort}Clients has Connected<3";
               // ListBox1.Items.Add(e.IpPort);
            });
        }

        private void rtbChats_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            if(txtText.Text.Trim() != "")
            {
                client.Send(txtText.Text);
                rtbChats.Text += $"{Environment.NewLine} Me: {txtText.Text}";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                ip = txtIP.Text;
                client = new SimpleTcpClient(ip, 5555);
                client.Events.Connected += Events_Connected;
                client.Events.Disconnected += Events_Disconnected;
                client.Events.DataReceived += Events_DataReceived;
                
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Error!");
            }
        }
    }
}
