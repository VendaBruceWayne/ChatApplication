﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SuperSimpleTcp;

namespace MessagingApp1._2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string ip;
        SimpleTcpServer server;
        

        private void btnStart_Click(object sender, EventArgs e)
        {
            try
            {
                ip = txtIP.Text;
                server = new SimpleTcpServer(ip, 5555);
                server.Events.ClientConnected += Events_ClientConnected;
                server.Events.DataReceived += Events_DataReceived;
                //server.Start(); 
                server.Events.ClientDisconnected += Events_ClientDisconnected;
                rtbChats.Text += $"{Environment.NewLine} Started...";
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Error!");
            }
           }

        private void Events_ClientDisconnected(object sender, ConnectionEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                rtbChats.Text += $"{Environment.NewLine} {e.IpPort} Disconnected...{e.Reason}";
                ListBox1.Items.Remove(e.IpPort);
                 
            });
        }

        private void Events_DataReceived(object sender, DataReceivedEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {

                byte[] receivedData = e.Data.ToArray();
                rtbChats.Text += $"{Environment.NewLine} {e.IpPort}: {Encoding.UTF8.GetString(receivedData)}";
            });
        }

        private void Events_ClientConnected(object sender, ConnectionEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                rtbChats.Text += $"{Environment.NewLine} {e.IpPort}Clients has Connected<3";
                ListBox1.Items.Add(e.IpPort);
            });
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            if(server.IsListening)
            {
                string message = txtText.Text;
                server.Send(ListBox1.SelectedItem.ToString(),message);
                rtbChats.Text += $"{Environment.NewLine}You: {message}";

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void rtbChats_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtText_TextChanged(object sender, EventArgs e)
        {

        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtIP_TextChanged(object sender, EventArgs e)
        {

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }
    }
}
